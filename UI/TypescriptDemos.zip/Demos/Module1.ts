module JS{
	export module TS{
		export class Foo{
		
		}
	}
}