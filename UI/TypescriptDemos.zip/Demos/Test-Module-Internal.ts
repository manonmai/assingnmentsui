/// <reference path="Module1.ts" />
/// <reference path="Module2.ts" />
var obj = JS.TS;
var fooObj = new obj.Foo();
var barObj = new obj.Bar();
