import fooModule = require('./Module3');
import barModule = require('./Module4');
var fooObj = new fooModule.Foo();
var barObj = new barModule.Bar();
