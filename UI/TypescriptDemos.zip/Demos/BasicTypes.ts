/*number type*/
var age:number = 33;

/*string type*/
var name:string = "Karthik";

/*boolean type*/
var maritalStatus:boolean = true;

/*number Array*/
var numbers:number[] =[1,2,3];

/*number Array - Generic*/
var numberList:Array<number> =[1,2,3];

/*Enum*/
enum Directions {NORTH, EAST, WEST, SOUTH};
var myDirection:Directions = Directions.EAST;

/*any type*/
var test:any = "Karthik"

/*void*/

function nothing(): void {
    alert("Function doesn't return a value");
}




